<select name="city" id="city" class="form-control selectBox-bg required">
    <option value="">Select City</option>
    %CITY_OPTION%
</select>