<div class="clearfix"></div>
<div class="form-group" id="123">
  <label class="control-label col-md-4">%LABEL%</label>
  <div class="col-md-7">
    <p class="%CLASS%">%VALUE%</p>
  </div>
</div>
<div class="clearfix"></div>
